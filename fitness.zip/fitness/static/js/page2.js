function func(i){
    console.log("iuyeuiryuif");
    var v = "mybutton" + String(i)
    document.getElementById(v).click();
    document.getElementById("modal-title").innerHTML = document.getElementById("first-txt").innerHTML;
    
}
function funct2(){
    document.getElementById("mymodal").style.display = "none";
}
